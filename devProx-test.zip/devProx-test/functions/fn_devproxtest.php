<?php

/* JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
 */

//This file stores all functions used

//Function to commit the data in the database
function postData($name, $surname, $idnumber, $dob) {
    
    $status = 2;
    
    $qry = " insert into customer (name, surname, id_number, dob) ";
    $qry .= " values ('$name', '$surname', '$idnumber', '$dob')";
    
    $result = DB::qry($qry);
  
    if ($result)
        $status = 1;
    return $status;
}

// Function to check wheter an ID exists in the DB
function checkId($idnumber) {
    
    $id = "";
    
    $qry = " select id from customer where id_number = '$idnumber'";
    
    $result = DB::qry($qry);

    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['id'];
    }
    return $id;
}

?>