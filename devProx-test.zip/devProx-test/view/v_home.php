<?php
/* JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
 */

//Start session 
if (session_id() == null) {
    session_start();
}

//Include functions and database connection files
include './functions/fn_devproxtest.php';
include './core/core_db.php';

$status = "";
$msg = "";

//Receive server side data 
if (isset($_GET['stat']))
    $status = $_GET['stat'];

if ($status == 1)
    $msg = "<p style='color:green;'> Post succesfully saved!</p>";
if ($status == 3)
    $msg = "<p style='color:red';> The ID you have entered exists in our records!</p>";
if ($status == 2)
    $msg = "<p style='color:red;'> Post not succesfully saved!</p>";

if (isset($_GET['msg']))
    $msg = $_GET['msg'];
?>

<!-- Javascript section -->

<script type='text/javascript'>

//Function to validate all input elements
    function checkInput() {

        var str_name = document.getElementById("txtname").value
        var str_surname = document.getElementById("txtsurname").value
        var str_idnumber = document.getElementById("txtidnumber").value
        var id_dd = document.getElementById("element_1_2").value
        var id_mm = document.getElementById("element_1_1").value
        var id_yy = document.getElementById("element_1_3").value

        if (id_dd == "") {
            alert("Please enter a date of birth")
            return false
        }

        var test_dd = /^\d+$/.test(id_dd)
        if ((test_dd === false) || (id_dd.length !== 2) || (id_dd > 31)) {
            alert("Please enter a valid date 'DD' ")
            return false
        }

        if (id_mm === "") {
            alert("Please enter a month of birth")
            return false
        }

        var test_mm = /^\d+$/.test(id_mm)
        if ((test_mm === false) || (id_mm.length !== 2) || (id_mm > 12)) {
            alert("Please enter a valid month 'MM' ")
            return false
        }

        if (id_yy === "") {
            alert("Please enter a year of birth")
            return false
        }

        var test_yy = /^\d+$/.test(id_yy)
        if ((test_yy === false) || (id_yy.length !== 4) || (id_yy > 2018)) {
            alert("Please enter a valid year 'YYYY' ")
            return false
        }

        if (str_name === "") {
            alert("Please enter a name ")
            return false
        }

        var test_name = /\d/.test(str_name)
        if (test_name === true) {
            alert("Please enter a valid name ")
            return false
        }

        if (str_surname === "") {
            alert("Please enter a surname ")
            return false
        }

        var test_surname = /\d/.test(str_surname)
        if (test_surname === true) {
            alert("Please enter a valid surname ")
            return false
        }

        if (str_idnumber === "") {
            alert("Please enter a valid ID Number ")
            return false
        }
        var testId = /^\d+$/.test(str_idnumber)
        if (testId === false) {
            alert("Please enter a valid ID Number ")
            return false
        }
        if (str_idnumber.length !== 13) {
            alert("Invalid ID Number, ID number should have 13 characters ")
            return false
        }

        var dob = id_yy + id_mm + id_dd
        var ck_dob = dob.substr(2)
        var ck_id = str_idnumber.substring(0, 6)

        if (ck_dob !== ck_id) {
            alert("The ID number and date of birth entered do not match!")
            return false
        }
    }

    //Function to clear input elements
    function clearInputs() {

        document.getElementById("txtname").value = ""
        document.getElementById("txtsurname").value = ""
        document.getElementById("txtidnumber").value = ""
        document.getElementById("element_1_2").value = ""
        document.getElementById("element_1_1").value = ""
        document.getElementById("element_1_3").value = ""
        document.getElementById("txtmsg").value = ""

    }

    //Function to validate input type to generated the file
    function validateGenerate() {

        var max_rec = document.getElementById("txtmaxRec").value

        var test_maxrec = /^\d+$/.test(max_rec)

        if ((test_maxrec === false) || (max_rec.length <= 0) || (max_rec === "")) {
            alert("Please enter a valid number of records to be generated. ")
            return false
        } else{
            window.open ("./controller/c_generate.php?mcount=" + max_rec, "_blank")
            document.getElementById("txtmaxRec").value = ""
        }
    }
</script>

<!-- HTML section -->

<body>
    <form name ="" method="POST" action="controller/c_post_data.php" onsubmit="return checkInput();">
        <div id="wrapper">
            <div class="shell" style="">
                <div id="header">

                    <div class="cl">&nbsp;</div>
                </div>       
                <div id="main" style="width: 955px;">
                    
                    <span id="textfields"><h2>DevProx JB | Test 1</h1></span>
                    <div style="width:300px; float: left">
                        <span><?php echo $msg; ?></span>  
                    </div>
                </div>
                <div id="main" style="width: 955px; height: 350px;" >

                    <table id="textfields" cellspacing="10px" style=" font-size:17px; text-align: left; width: 400px; " border="1">
                        <tr>
                            <td >Your Name:</td>
                            <td><input style="width:235px;" type="text" name ="txtname" id="txtname" value="<?php if (isset($_SESSION['name'])) echo $_SESSION['name']; ?>"/></td>
                        </tr>
                        <tr>
                            <td>Your Surname:</td>
                            <td><input style="width:235px;" type="text" name ="txtsurname" id="txtsurname" value="<?php if (isset($_SESSION['surname'])) echo $_SESSION['surname']; ?>"/></td>
                        </tr>
                        <tr>
                            <td>Your ID Number:</td>
                            <td><input style="width:235px;" type="text" name ="txtidnumber" id="txtidnumber" value="<?php if (isset($_SESSION['idnumber'])) echo $_SESSION['idnumber']; ?>"/></td>
                        </tr>            
                    </table>
                    <div id="form_container" style="float:left; width:400px; font-size:15px; padding-top:5px;">
                        <ul>

                            <span style="padding-left:10px;">
                                <label ><b>Date of Birth: </b></label>
                            </span>                         
                            <span>
                                <input id="element_1_2" name="txtdd" class="element text" size="1" maxlength="2" value="<?php if (isset($_SESSION['dob_dd'])) echo $_SESSION['dob_dd']; ?>" type="text"> /
                                <label for="element_1_2">DD</label>
                            </span>
                            <span>
                                <input id="element_1_1" name="txtmm" class="element text" size="1" maxlength="2" value="<?php if (isset($_SESSION['dob_mm'])) echo $_SESSION['dob_mm']; ?>" type="text"> /
                                <label for="element_1_1">MM</label>
                            </span>
                            <span>
                                <input id="element_1_3" name="txtyy" class="element text" size="2" maxlength="4" value="<?php if (isset($_SESSION['dob_yy'])) echo $_SESSION['dob_yy']; ?>" type="text">
                                <label for="element_1_3">YYYY</label>
                            </span>

                            <span id="calendar_1"><a>
                                    <img id="cal_img_1" class="datepicker" src="calendar.gif" alt="Pick a date."></a>
                            </span>
                            <script type="text/javascript">
                                Calendar.setup({
                                    inputField: "element_1_3",
                                    baseField: "element_1",
                                    displayArea: "calendar_1",
                                    button: "cal_img_1",
                                    ifFormat: "%B %e, %Y",
                                    onSelect: selectDate
                                });
                            </script>                           
                        </ul>
                        <div style="padding-top: 20px;">
                            <span><input type="submit" name="btnSubmit" id="btnSubmit" value="POST"</span>

                            <span><input type="button" name="btnCancel" id="btnCancel" value="CANCEL" onclick="clearInputs();"</span>
                        </div>

                    </div>

                </div>  

                <div id="main" style="width: 955px; "><span style="text-align: center; padding-bottom: 20px;">*****************************************************************</span>
                    <span ><h2>DevProx JB | Test 2</h1></span>
                    <div style="width:300px; float: left">
                        <span><?php //echo $msg;       ?></span>  
                    </div>

                    <table style="padding-top: 30px; padding-bottom: 30px;">
                        <tr>
                            <td> Enter number of records:</td>
                            <td><input type="text" name="txtmaxRec" id ="txtmaxRec" size="7"/></td>
                            <td><input type="button" name="btnGenerate" id ="btnGenerate" value="Generate" onclick="validateGenerate();"/></td>
                        </tr>
                    </table>
                    <span><a  style="text-decoration: none; font-weight: bold;" href="upload.php" target="_blank"<a/>Upload CSV file to DB</span>
                </div>
            </div>

            <span>
                <input type="hidden" name="txthdname" id="txthdname" value="<?php if (isset($_SESSION['name'])) echo $_SESSION['name']; ?>" />
                <input type="hidden" name="txthdsurname" id="txtsurname" value="<?php if (isset($_SESSION['surname'])) echo $_SESSION['surname']; ?>" />
                <input type="hidden" name="txthdidnumber" id="txtidnumber" value="<?php if (isset($_SESSION['idnumber'])) echo $_SESSION['idnumber']; ?>" />
                <input type="hidden" name="txthddd" id="txtidnumber" value="<?php if (isset($_SESSION['dob_dd'])) echo $_SESSION['dob_dd']; ?>" />
                <input type="hidden" name="txthdmm" id="txtmm" value="<?php if (isset($_SESSION['dob_mm'])) echo $_SESSION['dob_mm']; ?>" />
                <input type="hidden" name="txthdyy" id="txtmm" value="<?php if (isset($_SESSION['dob_yy'])) echo $_SESSION['dob_yy']; ?>" />
                <input type="hidden" name="txtmsg" id="txtmsg" value="<?php $msg; ?>" />
            </span>

