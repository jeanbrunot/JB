<?php
/* JB KING
 * DEVPROX TEST Oct1 21, 2018
 * 072 290 3449
 */

//Start session 
if (session_id() == null) {
    session_start();
}

//Include functions and database connection files
include './functions/fn_devproxtest.php';
include './core/core_db.php';

?>

<script type='text/javascript'>

    function validate() {
        var myfile;
        
      myfile = document.getElementById('myfile').value;
        if (myfile == "") {
            alert("No file selected, please choose a file to upload.")
            return false;
        }
        if(myfile.indexOf(".csv")==0){
            alert("Please upload a valid csv file.")
            return false;
        }
    }

    function loadData() {
        var filename = document.getElementById('txtfilename').value;
        window.location.href = "./controller/c_loadExcelData.php?filename=" + filename;
        return true;
    }

</script>
<body >

    <div id="wrapper">
        <div class="shell" style="">
            <div id="header">
                <div class="cl">&nbsp;</div>
            </div>
            <form id="" method="POST" action="./controller/c_uploadfile.php" enctype="multipart/form-data" onsubmit=" return validate();">
                <div id="tmain" style="width: 955px;">

                    <div style="width:800px; float: left; padding-bottom:5px;">
                        <span id="textfields"><h2>UPLOAD CSV FILE</h2></span>
                    </div>
                </div>
                <div style="width:980px; padding-top:100px; ">

                    <div >              
                        <table cellspacing ="10px">
                            <tr colspan="1">
                                <td> <input style="width:200px; height:30px;" type="file" id ="myfile" value="" name="file" /></td>
                            </tr>
                            <tr colspan="">
                                <td><input  style="width:120px; height:30px;" type="submit" value="Upload & Load Data" onclick="return validate();"/></td>
                            </tr>
                            <tr><td><hr></td></tr>
                        </table>
                    </div>
                    

                </div>
            </form>
        </div>

