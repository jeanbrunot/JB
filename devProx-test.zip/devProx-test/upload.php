<?php

/*JB KING
 * DEVPROX TEST Oct1 21, 2018
 * 072 290 3449
*/
include "includes/header.php";
include "view/v_upload.php";
include "includes/footer.php";