<?php
/*JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
*/
?>

<div id="footer-push"></div>
</div>
</form>
<div class="footer">
    <div class="shell">
        <p class="lf">Copyright &copy; 2018 <a href="#"></a>All Rights Reserved</p>
        <p class="rf"/> Devprox.com</a></p>
        <div style="clear:both;"></div>
    </div>
</div>
<!-- END PAGE SOURCE -->
</body>
</html>
