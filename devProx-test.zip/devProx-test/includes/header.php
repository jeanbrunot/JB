<?php
/*JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
*/
?>
<head>
    <title>DevProx Test | By JB Oct 2018 </title>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <link rel="shortcut icon" href="devprox_logo.jpg"/>
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <script src="js/jquery-1.4.2.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="js/jquery.jcarousel.pack.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript" src="js/view.js"></script>
    <script type="text/javascript" src="js/calendar.js"></script>
    <link rel="stylesheet" type="text/css" href="css/view.css" media="all">
    <script src="js/func.js" type="text/javascript" charset="utf-8"></script>
  
</head>
