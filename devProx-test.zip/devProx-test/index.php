<?php
/*JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
*/
include "includes/header.php";
include "view/v_home.php";
include "includes/footer.php";
?>
