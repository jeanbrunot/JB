<?php

/* JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
 */

//Start the session
if (session_id() == null) {
    session_start();
}

//Include required files
require_once "../classes/PHPExcel.php";
include "../core/core_db.php";
include "../functions/fn_devproxtest.php";

//Declare the max number of records
$max_rec = 0;

//Receive the amount of records to be generated
if(isset($_GET['mcount'])&&(is_numeric($_GET['mcount'])&&($_GET['mcount']> 0))){
    
    $max_rec = $_GET['mcount'];

//Arrays of names, surnames and the records
$names = array("Cuthbert", "Edmore", "Edmond", "Marko", "Tobias", "Brian", "Gordon", "Stephen", "Albert", "Daniel", "Vallance", "Edgar", "Jonathan", "Patrick", "Elizabeth", "Bruno", "Johnson", "Jacob", "David", "Jacob");
$surnames = array("MPOFU", "DUBE", "MOYO", "MATEWU", "SITHOLE", "BILLAH", "SIMBANEGAVI", "NYOKANHETE", "CHADZAMIRA", "KHAN", "CARSON", "EDWARDS", "SALAH", "CHAMBERS", "BUSH", "YOUNG", "EDWARDS", "KEMP", "VAN ZYL", "WEBB");
$recsArray = array();

//Output the csv file
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="output.csv"');

//Open csv file for writing
$file = fopen("php://output", "w");

// csv file headers
$line = "Id, Name, Surname, Initials, Age, DateOfBirth ";

//Write the headers to csv file
fputcsv($file, explode(',', $line));

//Initiate the record counter 
$rec_count = 0;

//Perform the process until the desired number of records is reached
while ($rec_count < $max_rec) {

    //Generate random DoB and names
    $dob_dd = mt_rand(1, 30);
    $dob_mm = mt_rand(1, 12);
    $dob_yy = mt_rand(1970, 2008);

    //Add leading zero to day and month if single digit
    if (strlen($dob_dd) == 1) {
        $dob_dd = "0" . $dob_dd;
    }

    if (strlen($dob_mm) == 1) {
        $dob_mm = "0" . $dob_mm;
    }
    
    //Construct the DOB
    $Dob = $dob_dd . "/" . $dob_mm . "/" . $dob_yy;
    
    //Compute age 
    $age = 2018 - $dob_yy;

    //Get values of the randomly generated name and surname 
    $nameIndex = array_rand($names);

    $surnameIndex = array_rand($surnames);

    //Construct the record
    $record = $names[$nameIndex] . "," . $surnames[$surnameIndex] . "," . substr($names[$nameIndex], 0, 1) . "," . $age . "," . $Dob;

    //Check if record exists in array, if not duplicate then proceed
    if (in_array($record, $recsArray) == false) {
        $rec_count++;
        $recsArray[] = $record;
        $line = $rec_count . "," . $names[$nameIndex] . "," . $surnames[$surnameIndex] . "," . substr($names[$nameIndex], 0, 1) . "," . $age . ", " . $Dob;
        fputcsv($file, explode(',', $line));
    }
}

//Close the file
fclose($file);

}
//echo "Write to file completed";

  