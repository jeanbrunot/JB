<?php

/* JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
 */

if (session_id() == null) {
    session_start();
}

require_once "../classes/PHPExcel.php"; //This class will be used in the second test
include "../core/core_db.php";
include "../functions/fn_devproxtest.php";

$name = "";
$surname = "";
$idnumber = "";
$dob_dd = "";
$dob_mm = "";
$dob_yy = "";

if (isset($_POST['txtname']))
    $name = $_POST['txtname'];

if (isset($_POST['txtsurname']))
    $surname = $_POST['txtsurname'];

if (isset($_POST['txtidnumber']))
    $idnumber = $_POST['txtidnumber'];

if (isset($_POST['txtdd']))
    $dob_dd = $_POST['txtdd'];

if (isset($_POST['txtmm']))
    $dob_mm = $_POST['txtmm'];

if (isset($_POST['txtyy']))
    $dob_yy = $_POST['txtyy'];

$dob = $dob_yy . "/" . $dob_mm . "/" . $dob_dd;

if (($name !== "") && ($surname !== "") && ($idnumber) && ($dob_dd !== "") && ($dob_mm !== "") && ($dob_yy !== "")) {

    if (checkId($idnumber) == "") {
        
        $status = postData($name, $surname, $idnumber, $dob);
        
        unset($_SESSION['name']);

        unset($_SESSION['surname']);

        unset($_SESSION['idnumber']);

        unset($_SESSION['dob_dd']);

        unset($_SESSION['dob_mm']);

        unset($_SESSION['dob_yy']);
    } else {
        $status = 3;
        $_SESSION['name'] = $name;

        $_SESSION['surname'] = $surname;

        $_SESSION['idnumber'] = $idnumber;

        $_SESSION['dob_dd'] = $dob_dd;

        $_SESSION['dob_mm'] = $dob_mm;

        $_SESSION['dob_yy'] = $dob_yy;
    }
}

header("Location: ../index.php?stat=$status");

