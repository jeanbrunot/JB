<?php

/* JB KING
 * DEVPROX TEST Oct1 21, 2018
 * 072 290 3449
 */

//Start the session
if (session_id() == null) {
    session_start();
}

//Include required files
require_once "../classes/PHPExcel.php";
include "../core/core_db.php";
include "../functions/fn_devproxtest.php";

//Declare the max number of records
$max_rec = 0;

//Retrieve the uploaded file
$file = $_FILES ['file']['name'];

//Check if file has been successfully received then proceed
if (($file)&&(strpos($file, ".csv")!== false)) {
    //Declare file directory
    $filedir = "../csv/" . $file;
    //Copy uploaded file to a new solution directory csv
    $copied = copy($_FILES['file']['tmp_name'], $filedir);

    //Create table if it doesn't exist
    $qry = " CREATE TABLE IF NOT EXISTS CSV_IMPORT (ID INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(ID) ,";
    $qry .= " NAME TEXT(50), SURNAME TEXT(50), INITIAL TEXT(3), AGE INT(3), DOB TEXT(10) )";

    //Execute table creation
    $createStatus = DB::qry($qry);

    //Display feedback if table is successfully created 
    if ($createStatus) {

        echo "<p style='color:green;'> Table created </p>";
        
        //Pause the script for 10 secs
        sleep(10);
        
        //Load the data from the csv file into the newly created table
        $loadqry = " LOAD DATA LOCAL INFILE '$filedir' INTO TABLE CSV_IMPORT ";
        $loadqry .= " FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 ROWS ";
        $loadqry .= " (id, name, surname, initial, age, dob) ";
        
        //Execute data loading query
        $loadStatus = DB::qry($loadqry);

        //Display feedback message if data loaded successfully
        if ($loadStatus)
            echo "<p style='color:green;'>Data successfully loaded </p>";
    }
}
else
    echo "<p style='color: red;'>Unsuccessful, invalid file uploaded</p>";

