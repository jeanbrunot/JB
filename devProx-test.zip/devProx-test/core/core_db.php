<?php
/*JB KING
 * DEVPROX TEST Oct1 18, 2018
 * 072 290 3449
*/

class DB


{
	public static $db = "devprox_test";
        public static $server = "localhost";
    	public static $username = "root";
    	public static $dpassword = "";        
	
	public static function qry($qry)
	{
		$conn = new mysqli(self::$server, self::$username, self::$dpassword);
		$conn->select_db(self::$db);
		if (!$conn ) {
		die('Could not connect: ' . mysql_error());
		}
		
		$rsl = $conn->query($qry);
                $conn->close();
		return $rsl;

	}
	
}
	


?>